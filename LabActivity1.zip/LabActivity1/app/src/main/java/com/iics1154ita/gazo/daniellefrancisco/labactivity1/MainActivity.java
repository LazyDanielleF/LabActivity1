package com.iics1154ita.gazo.daniellefrancisco.labactivity1;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void logGreetings(View view){
        for(int i = 1; i <= 10; i++){
            Log.d("Greetings","Greetings! * " + i);
        }
    }

    public void GoToPortals(View view){
        Intent i = new Intent(this, Main2Activity.class);
        startActivity(i);
    }
}
