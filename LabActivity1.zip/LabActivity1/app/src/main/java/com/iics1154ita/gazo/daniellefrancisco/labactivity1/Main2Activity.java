package com.iics1154ita.gazo.daniellefrancisco.labactivity1;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void USTWebsite(View v){
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse("http://ust.edu.ph/"));
        startActivity(i);
    }

    public void MyUSTe(View v){
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse("https://myuste.ust.edu.ph/"));
        startActivity(i);
    }

    public void BB(View v){
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse("https://ust.blackboard.com/"));
        startActivity(i);
    }
}
